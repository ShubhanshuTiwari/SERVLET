package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import com.cg.dto.CarDTO;

public class CarDAOImpl implements CarDAO{

	private Map<Integer, CarDTO> cardetails;
	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub\
		List<CarDTO> list=new ArrayList<>(cardetails.values());
		return list;
		
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		
		return cardetails.get(id);
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		CarDTO carDTO;
		carDTO=cardetails.putIfAbsent(10, new CarDTO());
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		
		/*if(cardetails.get(id)==null)
			
		cardetails.put(id, account);
		
		return true;*/
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}

}
